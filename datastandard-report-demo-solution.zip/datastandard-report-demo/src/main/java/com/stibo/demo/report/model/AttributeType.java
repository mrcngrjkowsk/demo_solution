package com.stibo.demo.report.model;

public class AttributeType   {
  private String id;
  private Boolean multiValue;

  public String getId() {
    return id;
  }

  public void setId(String id) {
    this.id = id;
  }

  public Boolean getMultiValue() {
    return multiValue;
  }

  public void setMultiValue(Boolean multiValue) {
    this.multiValue = multiValue;
  }
}

