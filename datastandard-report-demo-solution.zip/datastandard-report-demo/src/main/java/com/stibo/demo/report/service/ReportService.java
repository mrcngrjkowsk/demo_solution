package com.stibo.demo.report.service;

import com.stibo.demo.report.logging.LogTime;
import com.stibo.demo.report.model.*;
import org.apache.commons.lang3.tuple.Pair;
import org.springframework.stereotype.Service;

import java.util.*;
import java.util.function.Function;
import java.util.stream.Collectors;
import java.util.stream.Stream;

@Service
public class ReportService {

    @LogTime
    public Stream<Stream<String>> report(Datastandard datastandard, String categoryId) {
        Map<String, Attribute> attributeMap = datastandard.getAttributes().stream().collect(Collectors.toMap(Attribute::getId, Function.identity()));
        Map<String, Category> categoryMap = datastandard.getCategories().stream().collect(Collectors.toMap(Category::getId, Function.identity()));

        List<Category> categories = getCategories(categoryId, new ArrayList<>(), categoryMap);

        return getLevel3report(categories, attributeMap);
    }

    private Stream<Stream<String>> getLevel3report(List<Category> categories, Map<String, Attribute> attributeMap) {
        ;
        return Stream.concat(Stream.of(Stream.of("Category Name", "Attribute Name", "Description", "Type", "Groups")),
                categories.stream()
                .flatMap(
                        category -> category.getAttributeLinks().stream().map(attributeLink -> Pair.of(category.getName(), attributeLink))
                )
                .map(pair -> {
                    Attribute attribute = attributeMap.get(pair.getRight().getId());
                    return Stream.of(
                            pair.getLeft(),
                            getAttributeName(attribute, pair.getRight()),
                            attribute.getDescription(),
                            getAttributeTypes(attribute, attributeMap),
                            getGroupIds(attribute)
                    );
                }));
    }

    private List<Category> getCategories(String categoryId, List<Category> categories, Map<String, Category> categoryMap) {
        if (categoryMap.get(categoryId).getParentId() == null) {
            categories.add(categoryMap.get(categoryId));
            return categories;
        } else {
            categories.add(categoryMap.get(categoryId));
            return getCategories(categoryMap.get(categoryId).getParentId(), categories, categoryMap);
        }
    }

    private String getAttributeName(Attribute attribute, AttributeLink attributeLink) {
        return attribute.getName() + (!attributeLink.getOptional() ? "*" : "");
    }

    private String getGroupIds(Attribute attribute) {
        return String.join("\n", attribute.getGroupIds());
    }

    private String getAttributeType(Attribute attribute) {
        return attribute.getType().getId() + (attribute.getType().getMultiValue() ? "[]" : "");
    }

    private String getAttributeTypes(Attribute attribute, Map<String, Attribute> attributeMap) {

        if (attribute.getAttributeLinks() == null || attribute.getAttributeLinks().isEmpty()) {
            return getAttributeType(attribute);
        } else {
            StringBuilder stringBuilder = new StringBuilder();
            getRecursivelyAttributeTypes(attribute, attribute.getAttributeLinks().get(0), attributeMap, stringBuilder, 0);
            return stringBuilder.toString();
        }

    }

    private String getRecursivelyAttributeTypes(
            Attribute currentAttribute, AttributeLink currentAttributeLink, Map<String, Attribute> attributeMap, StringBuilder builder, int indentSize
    ) {
        if (currentAttribute.getAttributeLinks() == null || currentAttribute.getAttributeLinks().isEmpty()) {
            return getAttributeName(currentAttribute, currentAttributeLink) + ": " + currentAttribute.getType().getId();
        } else {
            if (indentSize == 0) {
                builder.append("composite{").append(System.lineSeparator());
            } else {
                builder.append(getIndent(indentSize)).append(getAttributeName(currentAttribute, currentAttributeLink)).append(": ").append("composite{").append(System.lineSeparator());
            }

            indentSize += 2;
            for (AttributeLink attributeLink : currentAttribute.getAttributeLinks()) {
                Attribute attribute = attributeMap.get(attributeLink.getId());

                if (attribute.getAttributeLinks() == null || attribute.getAttributeLinks().isEmpty()) {
                    builder.append(getIndent(indentSize)).append(getAttributeName(attribute, attributeLink)).append(": ").append(attribute.getType().getId()).append(System.lineSeparator());
                } else {
                    getRecursivelyAttributeTypes(attribute, attributeLink, attributeMap, builder, indentSize);
                }
            }
            indentSize -= 2;
            if (indentSize == 0) {
                builder.append(getIndent(indentSize)).append("}[]");
            } else {
                builder.append(getIndent(indentSize)).append("}[]").append(System.lineSeparator());
            }
        }

        return builder.toString();
    }

    private String getIndent(int size) {
        StringBuilder result = new StringBuilder();

        for (int i = 0; i < size; i++) {
            result.append(" ");
        }

        return result.toString();
    }
}
