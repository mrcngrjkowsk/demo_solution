CREATE TABLE books (
  isbn VARCHAR(13) PRIMARY KEY,
  title VARCHAR(50),
  author VARCHAR(50),
  category VARCHAR(50),
  borrower VARCHAR(50)
);