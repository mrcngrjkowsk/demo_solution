package com.datasystem.booksconsumer;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BooksConsumerApplication {

	public static void main(String[] args) {
		SpringApplication.run(BooksConsumerApplication.class, args);
	}
}
