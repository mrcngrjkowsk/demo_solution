package com.datasystem.booksconsumer.service;

import com.datasystem.booksconsumer.model.Book;
import com.datasystem.booksconsumer.model.BookMessage;
import com.datasystem.booksconsumer.repository.BooksRepository;
import org.springframework.kafka.annotation.KafkaHandler;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.messaging.handler.annotation.Payload;
import org.springframework.stereotype.Component;

@KafkaListener(topics = "booksTopic", groupId = "bookConsumerGroup", containerFactory = "bookMessageKafkaListenerContainerFactory")
@Component
public class BookMessageMessageHandler {

    private final BooksRepository booksRepository;

    public BookMessageMessageHandler(BooksRepository booksRepository) {
        this.booksRepository = booksRepository;
    }

    @KafkaHandler
    public void handleBookMessage(@Payload BookMessage bookMessage) {
        booksRepository.save(new Book(bookMessage.getIsbn(), bookMessage.getTitle(), bookMessage.getAuthor(), bookMessage.getCategory(), bookMessage.getBorrower()));
    }
}
