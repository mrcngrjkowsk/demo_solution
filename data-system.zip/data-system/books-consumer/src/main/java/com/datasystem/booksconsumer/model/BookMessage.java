package com.datasystem.booksconsumer.model;

import lombok.Data;

@Data
public class BookMessage {

    private String title;
    private String author;
    private String isbn;
    private String category;
    private String borrower;

    public BookMessage() {
    }

    public BookMessage(String borrower, String category, String isbn, String title, String author) {
        this.borrower = borrower;
        this.category = category;
        this.isbn = isbn;
        this.title = title;
        this.author = author;
    }
}