package com.datasystem.booksconsumer.model;

import lombok.Data;

@Data
public final class BorrowBookMessage {

    private String isbn;
    private String borrower;

    public BorrowBookMessage() {
        ;
    }

    public BorrowBookMessage(String isbn, String borrower) {
        this.isbn = isbn;
        this.borrower = borrower;
    }
}
