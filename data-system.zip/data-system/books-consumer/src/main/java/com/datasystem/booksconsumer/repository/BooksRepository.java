package com.datasystem.booksconsumer.repository;

import com.datasystem.booksconsumer.model.Book;
import org.springframework.data.repository.CrudRepository;

import java.util.List;

public interface BooksRepository extends CrudRepository<Book, String> {
    List<Book> findByBorrowerIsNotNull();
}
