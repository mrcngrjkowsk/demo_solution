package com.datasystem.booksconsumer.service;

import com.datasystem.booksconsumer.model.BorrowBookMessage;
import com.datasystem.booksconsumer.repository.BooksRepository;
import org.springframework.kafka.annotation.KafkaHandler;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.messaging.handler.annotation.Payload;
import org.springframework.stereotype.Component;

@KafkaListener(topics = "booksTopic", groupId = "bookConsumerGroup", containerFactory = "borrowBookMessageKafkaListenerContainerFactory")
@Component
public class BorrowBookMessageMessageHandler {

    private final BooksRepository booksRepository;

    public BorrowBookMessageMessageHandler(BooksRepository booksRepository) {
        this.booksRepository = booksRepository;
    }
    @KafkaHandler
    public void handleBorrowBookMessage(@Payload BorrowBookMessage borrowBookMessage) {
        //may be null also
        booksRepository.findById(borrowBookMessage.getIsbn()).ifPresent(book -> {
            book.setBorrower(borrowBookMessage.getBorrower());
            booksRepository.save(book);
        });
    }
}
