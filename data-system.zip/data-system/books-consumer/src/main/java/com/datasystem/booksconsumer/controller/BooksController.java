package com.datasystem.booksconsumer.controller;

import com.datasystem.booksconsumer.model.Book;
import com.datasystem.booksconsumer.model.BookMessage;
import com.datasystem.booksconsumer.repository.BooksRepository;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
public class BooksController {

    private final BooksRepository booksRepository;
    private final KafkaTemplate<String, BookMessage> kafkaTemplate;

    public BooksController(BooksRepository booksRepository, KafkaTemplate<String, BookMessage> kafkaTemplate) {
        this.booksRepository = booksRepository;
        this.kafkaTemplate = kafkaTemplate;
    }

    @GetMapping("/book")
    public List<Book> getBooks() {
        return booksRepository.findByBorrowerIsNotNull();
    }
}
