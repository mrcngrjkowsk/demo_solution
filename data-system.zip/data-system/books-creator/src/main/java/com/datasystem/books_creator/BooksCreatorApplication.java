package com.datasystem.books_creator;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BooksCreatorApplication {

	public static void main(String[] args) {
		SpringApplication.run(BooksCreatorApplication.class, args);
	}

}
