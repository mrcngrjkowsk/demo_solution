package com.datasystem.books_creator.model;

import jakarta.validation.constraints.NotEmpty;

public record BookRecord(
        @NotEmpty String title,
        @NotEmpty String author,
        @NotEmpty String isbn,
        @NotEmpty String category,
        String borrower
) {
}

