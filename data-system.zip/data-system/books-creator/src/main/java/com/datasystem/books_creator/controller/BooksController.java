package com.datasystem.books_creator.controller;

import com.datasystem.books_creator.model.BookRecord;
import com.datasystem.books_creator.service.BookService;
import jakarta.validation.Valid;
import jakarta.validation.constraints.NotEmpty;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@Validated
public class BooksController {

    private final BookService bookService;

    public BooksController(BookService bookService) {
        this.bookService = bookService;
    }

    @GetMapping("/book")
    public List<BookRecord> getBooks() {
        return bookService.getAllBooks();
    }

    @PostMapping("/book")
    public BookRecord addBook(@Valid @RequestBody BookRecord book){
        return bookService.addNewBook(book);
    }

    @PutMapping("/book")
    public BookRecord rentBook(@NotEmpty @RequestParam String clientName, @NotEmpty @RequestParam String isbn) {
        return bookService.rentBook(clientName, isbn);
    }
}
