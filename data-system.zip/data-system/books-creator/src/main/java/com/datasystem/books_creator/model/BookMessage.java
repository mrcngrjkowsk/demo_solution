package com.datasystem.books_creator.model;

import lombok.Data;

@Data
public class BookMessage {

    private final String title;
    private final String author;
    private final String isbn;
    private final String category;
    private final String borrower;

    public BookMessage(BookRecord bookRecord) {
        this.title = bookRecord.title();
        this.author = bookRecord.author();
        this.isbn = bookRecord.isbn();
        this.category = bookRecord.category();
        this.borrower = bookRecord.borrower();
    }

    public BookMessage(String borrower, String category, String isbn, String title, String author) {
        this.borrower = borrower;
        this.category = category;
        this.isbn = isbn;
        this.title = title;
        this.author = author;
    }
}
