package com.datasystem.books_creator.service;

import com.datasystem.books_creator.model.Book;
import com.datasystem.books_creator.model.BookMessage;
import com.datasystem.books_creator.model.BookRecord;
import com.datasystem.books_creator.model.BorrowBookMessage;
import com.datasystem.books_creator.repository.BookRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class BookService {

    private final BookRepository bookRepository;
    private final KafkaTemplate<String, BookMessage> kafkaTemplate;

    @Autowired
    public BookService(BookRepository bookRepository, KafkaTemplate<String, BookMessage> kafkaTemplate) {
        this.bookRepository = bookRepository;
        this.kafkaTemplate = kafkaTemplate;
    }

    public List<BookRecord> getAllBooks() {
        return bookRepository.findAll().stream().map(this::mapToBookRecord).toList();
    }
    public BookRecord addNewBook(BookRecord bookRecord){
        Book book = bookRepository.insert(mapToBook(bookRecord));
        kafkaTemplate.send("booksTopic", mapToBookMessage(book));
        return mapToBookRecord(book);
    }
    public BookRecord rentBook(String clientName, String isbn){
        //optional cause byIsbn may be null
        Book byIsbn = bookRepository.findByIsbn(isbn);
        byIsbn.setBorrower(clientName);
        Book book = bookRepository.save(byIsbn);
        kafkaTemplate.send("booksTopic",mapToBookMessage(book));
        return mapToBookRecord(book);
    }

    private BookRecord mapToBookRecord(Book book) {
        return new BookRecord(book.getTitle(), book.getAuthor(), book.getIsbn(), book.getCategory(), book.getBorrower());
    }

    private Book mapToBook(BookRecord bookRecord) {
        return new Book(bookRecord.borrower(), bookRecord.category(), bookRecord.title(), bookRecord.author());
    }

    private BookMessage mapToBookMessage(Book book) {
        return new BookMessage(book.getBorrower(), book.getCategory(), book.getIsbn(), book.getTitle(), book.getAuthor());
    }

    private BorrowBookMessage mapToRentBookMessage(Book book) {
        return new BorrowBookMessage(book.getIsbn(), book.getBorrower());
    }
}