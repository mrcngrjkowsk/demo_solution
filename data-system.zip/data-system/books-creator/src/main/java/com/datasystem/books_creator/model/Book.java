package com.datasystem.books_creator.model;

import lombok.Data;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

@Document
@Data
public class Book {

    public Book(String borrower, String category, String title, String author) {
        this.borrower = borrower;
        this.category = category;
        this.title = title;
        this.author = author;
    }


    @Id
    private String isbn;
    private String title;
    private String author;
    private String category;
    private String borrower;
}
