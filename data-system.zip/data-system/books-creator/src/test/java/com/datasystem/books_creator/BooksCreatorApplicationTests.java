package com.datasystem.books_creator;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.context.annotation.Import;

@Import(TestcontainersConfiguration.class)
@SpringBootTest
class BooksCreatorApplicationTests {

	@Test
	void contextLoads() {
	}

}
